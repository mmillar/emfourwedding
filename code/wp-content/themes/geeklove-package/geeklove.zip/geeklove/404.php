<?php get_header(); ?>

<div class="container error-404 center">
    <h1><?php _e( 'Error 404 - Not Found', 'stag' ); ?></h1>
</div>

<?php get_footer(); ?>
